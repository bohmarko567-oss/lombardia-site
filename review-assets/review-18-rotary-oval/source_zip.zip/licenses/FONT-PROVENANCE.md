# Font provenance — inspected 2026-09-09

Real source files: `C:/Users/bohma/code ux rep/lombardia/fonts/`. Extracted each TrueType name table directly with Python standard library; raw identity, copyright, designer, license metadata and SHA-256 are in `font-metadata.json`. No fonts installed or modified.

| File | Verified family/style | Embedded authorship | License |
| --- | --- | --- | --- |
| BodoniModa-var.ttf | Bodoni Moda; default Regular | Bodoni Moda Project Authors, 2020; Owen Earl / indestructible type | SIL OFL 1.1 |
| SairaCondensed-Bold.ttf | Saira Condensed Bold | Saira Project Authors, 2016; Hector Gatti with Omnibus-Type | SIL OFL 1.1; reserved name Saira |
| SairaCondensed-Medium.ttf | Saira Condensed Medium | Same Saira authorship | SIL OFL 1.1; reserved name Saira |
| IBMPlexMono-Regular.ttf | IBM Plex Mono Regular | IBM Corp., 2017; Mike Abbink, Paul van der Laan, Pieter van Rosmalen / Bold Monday | SIL OFL 1.1 |
| Spectral-Light.ttf | Spectral Light; typographic family Spectral/style Light | Spectral Project Authors, 2017; Jean-Baptiste Levee / Production Type | SIL OFL 1.1 |
| Yellowtail-Regular.ttf | Yellowtail Regular | Brian J. Bonislawsky DBA Astigmatic (AOETI), 2011 | Apache License 2.0 |

`CREDITS-serif.txt` incorrectly calls Spectral Light “Source Serif 4”. The actual binary identifies Spectral, and its copyright points to Production Type's Spectral project. This manifest corrects the description; the original credits file was not edited.

## License evidence

Full texts saved in `font-licenses/`:

- Bodoni Moda: https://raw.githubusercontent.com/google/fonts/main/ofl/bodonimoda/OFL.txt — fetched 2026-09-09.
- IBM Plex Mono: https://raw.githubusercontent.com/google/fonts/main/ofl/ibmplexmono/OFL.txt — fetched 2026-09-09.
- Spectral: https://raw.githubusercontent.com/google/fonts/main/ofl/spectral/OFL.txt — fetched 2026-09-09.
- Saira Condensed: existing `assets/_src/giuliatz-studio-di-forma/2026-09-09/fonts/SairaCondensed-OFL.txt`, copied unchanged. Text agrees with binary copyright/license metadata.
- Yellowtail: existing `assets/_src/giuliatz-studio-di-forma/2026-09-09/fonts/Yellowtail-LICENSE.txt`, copied unchanged. Apache 2.0 agrees with binary copyright record, which links http://www.apache.org/licenses/LICENSE-2.0.html.

Historical download URL/version provenance for all six exact binaries is UNKNOWN; metadata and hashes establish what is actually present, not a fresh upstream hash match. Font files have not been modified. These are studio typography choices, not authenticated automotive wordmarks or period model scripts. Carry the respective license/copyright texts if redistributing font binaries.
