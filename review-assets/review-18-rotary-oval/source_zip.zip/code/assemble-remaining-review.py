"""Review-only complete-plate assembler. Import is inert; no production exports."""
from pathlib import Path
import argparse, base64, hashlib, importlib.util, io, json, re, zipfile, shutil
from datetime import datetime, timezone
import fitz
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'work/scale-18'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def helper():
    # Module __main__ is never invoked; reuse cap-height vector outlines and LA asset.
    spec=importlib.util.spec_from_file_location('pilot_vector_helpers',BASE/'build-root-pilots.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def uri(data):return 'data:image/png;base64,'+base64.b64encode(data).decode()
def png(im):
    buf=io.BytesIO();im.save(buf,format='PNG');return buf.getvalue()

# x,y,cap-height are normalized trim dimensions. Width is a maximum, never a stretch.
TITLES={4:[('300',.065,.24,.12,.16),('SL',.065,.43,.17,.16)],5:[('E-type',.08,.76,.11,.52)],6:[('2000',.08,.20,.10,.19),('GT',.08,.37,.17,.19)],7:[('Z432',.07,.16,.16,.80)],8:[('P1800',.065,.70,.055,.50,-90)],9:[('M1',.06,.70,.20,.26)],10:[('quattro',-.015,.18,.105,.86)],11:[('STRATOS',.045,.91,.075,.80,-90)],12:[('500',.08,.10,.35,.81)],13:[('MI',.12,.59,.10,.32),('NI',.12,.73,.10,.32)],14:[('TURBO',-.04,.76,.25,1.08)],15:[('Fastback',.54,.11,.085,.37)],16:[('STING',.045,.15,.065,.15),('RAY',.045,.29,.09,.15)],17:[('NSX',.07,.25,.12,.70)],18:[('RX-7',.07,.75,.14,.81)]}
META={4:[('MERCEDES-BENZ',.27,.15),('1954',.84,.79)],5:[('JAGUAR',.08,.19),('1961 / 3.8 FHC',.76,.13)],6:[('TOYOTA / 1967',.08,.63)],7:[('FAIRLADY / 1969',.94,.45,90)],8:[('VOLVO / 1961',.68,.08)],9:[('BMW / 1978',.06,.12)],10:[('AUDI',.81,.075),('1980',.07,.89)],11:[('1973 / STRADALE',.57,.11),('LANCIA',.58,.88)],12:[('FIAT / NUOVA',.10,.85),('1957',.80,.90)],13:[('MORRIS MINI-MINOR',.57,.66),('1959',.78,.89)],14:[('RENAULT 5 / 1980',.07,.10)],15:[('1965',.82,.45),('FORD MUSTANG',.09,.87)],16:[('CORVETTE',.055,.61,90),('1963',.76,.86)],17:[('HONDA / 1990',.07,.50,90)],18:[('SAVANNA / 1978',.09,.12),('MAZDA',.94,.51,90)]}
COLLECTIONS={'sculpture':'FORMA / SCULPTURE','Japanese precision':'FORMA / PRECISION','road/rally energy':'FORMA / MOTION','everyday icons':'FORMA / EVERYDAY','American form':'FORMA / AMERICA'}
# Reviewed intended paper fields; recipes override after inspecting generated plates.
INKS={4:'#242B2B',5:'#E2E3CA',6:'#373B38',7:'#262C31',8:'#31454B',9:'#292C30',10:'#E8E4D9',11:'#24282B',12:'#F2DCB9',13:'#465C48',14:'#EEE4D1',15:'#E9D9BC',16:'#414449',17:'#1B2B32',18:'#4D694E'}
TITLE_INKS={13:'#F1E6C8',16:'#E7E0D0'}
BRANDS={4:(.68,.88,.20),5:(.71,.86,.20),6:(.60,.09,.20),7:(.09,.91,.20),8:(.48,.88,.20),9:(.65,.88,.20),10:(.58,.90,.25),11:(.55,.82,.23),12:(.10,.52,.23),13:(.59,.76,.23),14:(.60,.27,.23),15:(.72,.77,.20),16:(.62,.09,.23),17:(.57,.86,.23),18:(.54,.64,.23)}
# Critical model titles remain at least 5 mm plus clearance from trim.
TITLES[10]=[('quattro',.06,.18,.105,.86)]
TITLES[14]=[('TURBO',.06,.76,.17,.88)]

def assemble(number):
    gate=read(BASE/'review/pilot-publication-gate.json')
    if not all(gate.get(k) is True for k in ['pilot_publication_confirmed','notion_gate_confirmed','owner_review_generation_approved']):
        raise ValueError('Root-confirmed publication, Notion and owner review-generation gates required')
    plans=read(BASE/'research/remaining/art-directions.json');plan=next(x for x in plans['designs'] if x['id']==number)
    fact=next(x for x in read(BASE/'research/lineup-consolidated-18.json')['remaining'] if x['id']==number)
    folder=BASE/f'review/plates/{number:02d}';native=folder/'native.png';recipe=read(folder/'recipe.json')
    if recipe.get('design_id')!=number:raise ValueError('Recipe identity mismatch')
    if recipe.get('native_sha256')!=sha(native):raise ValueError('Recipe/source hash mismatch')
    w,h=(800,600) if plan['format_lock'].startswith('80') else (450,600)
    im=Image.open(native).convert('RGB');nw,nh=im.size
    ratio=min(w/nw,h/nh);cw,ch=nw*ratio,nh*ratio
    x,y,pw,ph=recipe.get('plate_box_mm',[(w-cw)/2,(h-ch)/2,cw,ch])
    if min(pw,ph)<=0 or x<0 or y<0 or x+pw>w+.001 or y+ph>h+.001:raise ValueError('Whole plate must fit trim')
    if abs(pw/ph-nw/nh)>0.0001:raise ValueError('Plate box would distort native image')
    if (x or y or pw!=w or ph!=h) and recipe.get('edge_paper_confirmed') is not True:raise ValueError('Empty edge-paper confirmation required')
    cropboxes=recipe['car_crop_boxes_px']
    if len(cropboxes)!=2:raise ValueError('Exactly two meaningful native car crop boxes required')
    for box in cropboxes:
        if len(box)!=4 or not all(isinstance(n,int) for n in box) or not (0<=box[0]<box[2]<=nw and 0<=box[1]<box[3]<=nh):raise ValueError('Invalid integer native crop')
    slug=re.sub('[^a-z0-9]+','-',plan['composition_name'].lower()).strip('-')
    out=ROOT/f'outputs/scale-18/review/{number:02d}-{slug}'
    if out.exists() and any(out.iterdir()):
        archive_dir=BASE/f'review/archive/{number:02d}'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
        archive_dir.parent.mkdir(parents=True,exist_ok=True)
        shutil.copytree(out,archive_dir)
    out.mkdir(parents=True,exist_ok=True)
    parts=[]
    # Extend only declared empty outer edge pixels; complete native plate stays uniform.
    if x or y or pw!=w or ph!=h:
        if recipe.get('empty_paper_box_px'):
            paper=im.crop(recipe['empty_paper_box_px'])
            parts.append(f'<image x="0" y="0" width="{w}" height="{h}" preserveAspectRatio="none" href="{uri(png(paper))}"/>')
            strips=[]
        else:
            strips=[(im.crop((0,0,nw,min(8,nh))),x,0,pw,y),(im.crop((0,max(0,nh-8),nw,nh)),x,y+ph,pw,h-y-ph),(im.crop((0,0,min(8,nw),nh)),0,0,x,h),(im.crop((max(0,nw-8),0,nw,nh)),x+pw,0,w-x-pw,h)]
        for strip,sx,sy,sw,sh in strips:
            if sw>0 and sh>0:parts.append(f'<image x="{sx}" y="{sy}" width="{sw}" height="{sh}" preserveAspectRatio="none" href="{uri(png(strip))}"/>')
    parts.append(f'<image x="{x}" y="{y}" width="{pw}" height="{ph}" href="{uri(native.read_bytes())}"/>')
    mod=helper();ink=recipe.get('ink',INKS[number]);fonts=set()
    def label(text,font,nx,ny,height,maxwidth=None,rotation=0,fill=None):
        f=Path(font).name;fonts.add(f)
        # Measure cap-based natural width first; fit uniformly rather than squash letters.
        cap=mod.ReportTTFont('review_metrics',str(mod.FONT/f)).face.capHeight
        natural=fitz.Font(fontfile=str(mod.FONT/f)).text_length(text,fontsize=1000)*height*h/cap
        actual=height*h*min(1,(maxwidth*w/natural)) if maxwidth and natural else height*h
        vector=mod.lettering(text,f,0,0,actual,fill or ink)
        parts.append(f'<g transform="translate({nx*w} {ny*h}) rotate({rotation})">{vector}</g>')
    for row in recipe.get('title_runs',TITLES[number]):
        text,nx,ny,hh,mw,*rot=row;label(text,plan['vector_type']['title_font'],nx,ny,hh,mw,rot[0] if rot else 0,recipe.get('title_ink',TITLE_INKS.get(number,ink)))
    for row in recipe.get('metadata_runs',META[number]):
        text,nx,ny,*rot=row;label(text,plan['vector_type']['secondary_font'],nx,ny,.014,None,rot[0] if rot else 0)
    # Root may place one/two sourced specs only where plate leaves paper clear.
    for item in recipe.get('spec_runs',[]):
        if item['text'] not in fact['specs']:raise ValueError('Spec text is not exact sourced record')
        label(item['text'],'IBMPlexMono-Regular.ttf',item['x'],item['y'],item.get('height',.012))
    if len(recipe.get('spec_runs',[]))>2:raise ValueError('At most two specs')
    bx,by,bw=recipe.get('brand_box_normalized',BRANDS[number])
    limit=.16 if w==800 else .24
    if bw>limit:
        if bx>=.45:bx+=bw-limit
        bw=limit
    brandink=recipe.get('brand_ink',ink)
    brandvector=mod.brand(bx*w,by*h,bw*w)
    # Recolour vector fills only; keep source geometry and source asset unchanged.
    brandvector=re.sub(r'fill="(?!none)[^"]+"',lambda m:'fill="'+brandink+'"',brandvector)
    parts.append(brandvector);fonts.add('Yellowtail-Regular.ttf')
    label(COLLECTIONS[plan['family']],'IBMPlexMono-Regular.ttf',bx, min(.985,by+.035),.0065,fill=brandink)
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}mm" height="{h}mm" viewBox="0 0 {w} {h}">'+''.join(parts)+'</svg>'
    (out/'artwork-native.svg').write_text(svg,encoding='utf-8')
    sd=fitz.open(stream=svg.encode(),filetype='svg');pdf=fitz.open('pdf',sd.convert_to_pdf())
    # PDF exists only in memory; deliberately no production PDF/JPG or upsampled master.
    scale=2000/max(pdf[0].rect.width,pdf[0].rect.height);pix=pdf[0].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
    Image.frombytes('RGB',[pix.width,pix.height],pix.samples).save(out/'artwork-review.jpg',quality=94)
    for idx,box in enumerate(cropboxes,1):im.crop(box).save(out/f'native-car-detail-{idx}.png')
    receipt=dict(design_id=number,identity=plan['identity_lock'],format_mm=[w,h],status='OWNER APPROVAL REQUIRED — REVIEW ONLY',source=str(native),source_sha256=sha(native),source_pixels=[nw,nh],plate_box_mm=[x,y,pw,ph],actual_native_ppi=nw/(pw/25.4),brand_box_normalized=[bx,by,bw],native_crop_boxes_px=cropboxes,reference_paths=plan['reference_paths'],facts=fact,fonts=[dict(path=str(mod.FONT/f),sha256=sha(mod.FONT/f)) for f in sorted(fonts)],recipe=recipe,gate=gate,limits='Native illustration remains its actual resolution; no production export or physical print validation.',outputs={f.name:sha(f) for f in out.iterdir() if f.is_file() and f.name not in ('manifest.json','review-manifest.json','source-kit.zip')})
    (out/'manifest.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding='utf-8');print(out)
    # Editable source kit: generated plate and licensed fonts, no reference photographs.
    archive=out/'source-kit.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as kit:
        for f in [out/'artwork-native.svg',out/'manifest.json',folder/'recipe.json']:
            kit.write(f,f.name)
        kit.write(native,'generated/native.png')
        for history in folder.glob('archive*'):
            if history.is_dir():
                for f in history.rglob('*'):
                    if f.is_file() and f.suffix.lower() in ['.png','.json']:
                        kit.write(f,'generated/history/'+str(f.relative_to(folder)).replace('\\','/'))
        kit.write(Path(__file__),'code/assemble-remaining-review.py')
        kit.write(BASE/'build-root-pilots.py','code/build-root-pilots.py')
        kit.write(BASE/'research/FONT-PROVENANCE.md','licenses/FONT-PROVENANCE.md')
        for f in sorted(fonts):kit.write(mod.FONT/f,'fonts/'+f)
        for f in (BASE/'research/font-licenses').iterdir():
            if f.is_file():kit.write(f,'licenses/'+f.name)
        brandfile=ROOT/'outputs/print-master/brand-assets/lombardia-wordmark-yellowtail.svg'
        kit.write(brandfile,'brand/'+brandfile.name)
    names={4:('Mercedes-Benz','300 SL',1954),5:('Jaguar','E-type Series 1 3.8 FHC',1961),6:('Toyota','2000GT MF10',1967),7:('Nissan','Fairlady Z432 PS30',1969),8:('Volvo','P1800 Jensen',1961),9:('BMW','M1 E26',1978),10:('Audi','quattro B2',1980),11:('Lancia','Stratos HF Stradale early',1973),12:('Fiat','Nuova 500 launch',1957),13:('Morris','Mini-Minor Number One',1959),14:('Renault','5 Turbo',1980),15:('Ford','Mustang Fastback 2+2 289 4V',1965),16:('Chevrolet','Corvette Sting Ray 327/360',1963),17:('Honda','NSX NA1 5MT',1990),18:('Mazda','Savanna RX-7 Limited',1978)}
    marque,model,year=names[number]
    def asset(f):return {'path':str(f.relative_to(ROOT)).replace('\\','/'),'sha256':sha(f)}
    assets={'poster':asset(out/'artwork-review.jpg'),'svg':asset(out/'artwork-native.svg'),'source_zip':asset(archive)}
    for idx,box in enumerate(cropboxes,1):
        a=asset(out/f'native-car-detail-{idx}.png');a.update(role=recipe.get('crop_roles',['front-glass-lights','wheel-body-grounding'])[idx-1],source_path=str(native.relative_to(ROOT)).replace('\\','/'),source_sha256=sha(native),crop_xyxy=box);assets[f'crop{idx}']=a
    sources=list(dict.fromkeys([fact[k] for k in ['primary_visual_page','spec_source','full_car_source'] if fact.get(k)]))
    board=dict(id=number,key=f'review-{number:02d}-{slug}',car_key=f'scale18-review-car-{number:02d}',car={'marque':marque,'model':model,'year':year},format_cm=[w/10,h/10],art_direction=recipe.get('actual_art_direction',plan['composition_name']+' / '+plan['family']),provenance={'text':'Generated complete native illustration; separate licensed vector type. Actual native PPI '+str(round(receipt['actual_native_ppi'],2))+'. Source photos used for reference only; copyright permission unknown. Owner approval required. Access date 2026-09-09.','sources':sources},palette=recipe.get('actual_palette',{'ground':plan['palette_hex'][0],'deep':plan['palette_hex'][1],'ink':ink}),assets=assets)
    (out/'review-manifest.json').write_text(json.dumps(board,indent=2,ensure_ascii=False),encoding='utf-8')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('design_id',type=int,choices=range(4,19));args=parser.parse_args();assemble(args.design_id)
