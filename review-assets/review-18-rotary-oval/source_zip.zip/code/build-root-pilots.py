"""Editable vector composition over preserved complete native illustration plates."""
from pathlib import Path
import base64, hashlib, json, re, shutil, io
import fitz
from PIL import Image
from reportlab.pdfbase.ttfonts import TTFont as ReportTTFont

ROOT=Path(__file__).resolve().parents[2]
FONT=Path('C:/Users/bohma/code ux rep/lombardia/fonts')
OUT=ROOT/'outputs/scale-18'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
_text_serial=0
def lettering(text,font,x,y,height,fill,tracking=0,width=None):
    global _text_serial
    _text_serial+=1
    f=fitz.Font(fontfile=str(FONT/font)); cap=ReportTTFont('studio',str(FONT/font)).face.capHeight
    scale=height/cap; advances=f.text_length(text,fontsize=1000)+tracking*(len(text)-1)
    sx=width/advances if width else scale
    d=fitz.open(); p=d.new_page(width=30000,height=3000)
    p.insert_font(fontname='studio',fontfile=str(FONT/font)); cursor=0
    rgb=tuple(int(fill[i:i+2],16)/255 for i in (1,3,5))
    for ch in text:
        p.insert_text((cursor,cap),ch,fontname='studio',fontsize=1000,color=rgb)
        cursor+=f.text_length(ch,fontsize=1000)+tracking
    src=p.get_svg_image(text_as_path=True)
    inner=re.sub(r'^.*?<svg[^>]*>','',src,flags=re.S).replace('</svg>','')
    ids=re.findall(r'id="([^"]+)"',inner)
    for ident in ids:
        inner=inner.replace('id="'+ident+'"','id="t'+str(_text_serial)+'_'+ident+'"').replace('#'+ident+'"','#t'+str(_text_serial)+'_'+ident+'"')
    return f'<g aria-label="{text}" transform="translate({x} {y}) scale({sx} {scale})">'+inner+'</g>'
def brand(x,y,width):
    src=(ROOT/'outputs/print-master/brand-assets/lombardia-wordmark-yellowtail.svg').read_text()
    inner=re.sub(r'^.*?<svg[^>]*>','',src,flags=re.S).replace('</svg>','')
    return f'<g transform="translate({x} {y}) scale({width/791})">{inner}</g>'
def build(key):
    is_sm=key=='citroen-sm-1970'; w,h=(800,600) if is_sm else (450,600)
    native=ROOT/'work/scale-18/references'/('sm-plate-original.png' if is_sm else 'porsche-plate-cabin-fixed.png')
    out=OUT/key; out.mkdir(parents=True,exist_ok=True); shutil.copy2(native,out/'native-illustration.png')
    plate_y=66.6666667 if is_sm else 179
    plate_h=w*1024/1536
    with Image.open(native) as im:
        sample=im.crop((0,0,1536,40)).resize((1,1)).getpixel((0,0)); native_size=list(im.size)
    bg='#%02x%02x%02x'%sample[:3]; ink='#203c4b' if is_sm else '#194d36'
    parts=[f'<rect width="{w}" height="{h}" fill="{bg}"/>',f'<image x="0" y="{plate_y}" width="{w}" height="{plate_h}" href="data:image/png;base64,{base64.b64encode(native.read_bytes()).decode()}"/>']
    # Extend only source paper outside the complete car/ground plate, no cutouts.
    with Image.open(native) as paper:
        strips=[(paper.crop((0,0,1536,40)),0,plate_y)]
        if plate_y+plate_h<h: strips.append((paper.crop((0,984,1536,1024)),plate_y+plate_h,h-plate_y-plate_h))
        for strip,sy,sh in strips:
            buf=io.BytesIO();strip.save(buf,format='PNG')
            parts.append(f'<image x="0" y="{sy}" width="{w}" height="{sh}" preserveAspectRatio="none" href="data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}"/>')
    text=lambda *a,**kw:parts.append(lettering(*a,**kw))
    if is_sm:
        text('CITROËN','SairaCondensed-Medium.ttf',32,30,13,ink,tracking=170)
        text('SM','SairaCondensed-Bold.ttf',494,42,127,ink,width=271)
        text('1970','IBMPlexMono-Regular.ttf',34,77,8,ink,tracking=30)
        text('LA FORME DU VENT','SairaCondensed-Medium.ttf',34,126,9,ink,tracking=90)
        text('COUPÉ GRAND TOURISME','IBMPlexMono-Regular.ttf',34,144,4.8,ink)
        parts.append('<path d="M34 190 H385 M34 199 H306 M34 208 H232" stroke="#839c9f" stroke-width=".65" fill="none"/>')
        specs=[('V6 MASERATI','2670 cm³'),('PUISSANCE','170 DIN PS'),('RÉGIME','5500 rpm'),('VITESSE','220 km/h')]
        for i,(a,b) in enumerate(specs):
            x=36+i*153
            text(a,'IBMPlexMono-Regular.ttf',x,533,4.2,ink)
            text(b,'SairaCondensed-Medium.ttf',x,547,8,ink)
        parts.append(brand(635,561,130))
        text('FORME / MOUVEMENT','IBMPlexMono-Regular.ttf',36,577,4.1,ink,tracking=25)
        titlecrop=[240,240,9200,2240]; carcrop=[240,3100,9200,5100]; speccrop=[240,6200,9200,6970]
    else:
        parts.append('<rect x="0" y="0" width="450" height="177" fill="#194d36"/>')
        text('PORSCHE','SairaCondensed-Medium.ttf',25,21,10,bg,tracking=170)
        text('911','SairaCondensed-Bold.ttf',22,49,109,bg,width=260)
        text('1973','IBMPlexMono-Regular.ttf',328,25,7.5,bg)
        text('CARRERA','SairaCondensed-Bold.ttf',304,92,14,bg)
        text('RS 2.7','SairaCondensed-Bold.ttf',304,116,27,bg,width=120)
        text('LEICHTBAU','IBMPlexMono-Regular.ttf',27,480,7,ink,tracking=100)
        text('M471 SPORT','SairaCondensed-Medium.ttf',298,480,7,ink,tracking=80)
        for x,a,b in [(27,'BOXER SIX','2687 cm³'),(165,'POWER','210 PS'),(305,'KERB WEIGHT','960 kg')]:
            text(a,'IBMPlexMono-Regular.ttf',x,513,3.8,ink)
            text(b,'SairaCondensed-Bold.ttf',x,526,10,ink)
        parts.append(brand(175,559,100))
        text('SPORT / LEICHT','IBMPlexMono-Regular.ttf',177,579,3.8,ink,tracking=30)
        titlecrop=[200,200,5100,1970]; carcrop=[200,2920,5100,4690]; speccrop=[220,5880,5090,6450]
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}mm" height="{h}mm" viewBox="0 0 {w} {h}">'+''.join(parts)+'</svg>'
    (out/'artwork-native.svg').write_text(svg,encoding='utf-8')
    doc=fitz.open(stream=svg.encode(),filetype='svg'); pdf=fitz.open('pdf',doc.convert_to_pdf()); pdf.save(out/'artwork.pdf',garbage=4,deflate=True)
    target=(9448,7086) if is_sm else (5314,7086)
    pix=pdf[0].get_pixmap(matrix=fitz.Matrix(target[0]/pdf[0].rect.width,target[1]/pdf[0].rect.height),alpha=False)
    im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    if im.size!=target: raise RuntimeError(('size',im.size,target))
    im.save(out/'artwork.jpg',quality=97,subsampling=0,dpi=(300,300))
    prev=im.copy(); prev.thumbnail((1600,1600)); prev.save(out/'artwork-preview.jpg',quality=93)
    for name,box in [('title',titlecrop),('paired-car',carcrop),('spec',speccrop)]: im.crop(box).save(out/f'detail-{name}.png')
    manifest={'design':key,'format_cm':[w/10,h/10],'native_source':str(native),'native_source_sha256':sha(native),'native_source_pixels':native_size,'plate_mm':[0,plate_y,w,plate_h],'effective_native_ppi':1536/(w/25.4),'export_pixels':target,'typography':'Separate true vector font outlines; not authentic manufacturer wordmarks','fonts_used':['SairaCondensed-Medium.ttf','SairaCondensed-Bold.ttf','IBMPlexMono-Regular.ttf','Yellowtail-Regular.ttf'],'crops':{'title':titlecrop,'paired-car':carcrop,'spec':speccrop},'status':'draft_for_independent_review','limits':'Native illustration detail is not 300 PPI. Export is a 300-PPI delivery grid with vector typography. No physical print inspected.','files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in out.iterdir() if p.is_file()}}
    (out/'artwork-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(key,target,manifest['effective_native_ppi'])
if __name__=='__main__':
    import sys
    for key in sys.argv[1:] or ['citroen-sm-1970','911-carrera-rs27-1973']:build(key)
